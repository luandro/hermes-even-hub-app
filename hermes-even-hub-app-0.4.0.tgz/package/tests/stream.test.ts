import { describe, it, expect } from "vitest";
import { getTextWidth } from "@evenrealities/pretext";
import {
  THREAD_BODY_INNER_WIDTH,
  THREAD_VIEWPORT_LINES,
  VIEWPORT_BYTE_BUDGET,
  byteLength,
  clampToBudget,
  currentThreadViewport,
  nextThreadViewportCursor,
  previousThreadViewportIndex,
  streamToText,
  threadPages,
  threadViewports,
  wrapTextLines,
} from "../src/ui/stream";
import type { StreamItem } from "../src/state/store";

const RULE = "─".repeat(26);

describe("streamToText", () => {
  it("> user, / tool (running/done/failed), plain assistant", () => {
    const items: StreamItem[] = [
      { kind: "user", text: "add dark mode" },
      { kind: "tool", name: "terminal", running: false, ok: true },
      { kind: "assistant", text: "Added it." },
      { kind: "tool", name: "grep", running: true },
    ];
    expect(streamToText(items)).toBe(
      "> add dark mode\n/ terminal ok\nAdded it.\n/ grep",
    );
  });
  it("renders tool labels when present", () => {
    expect(streamToText([{ kind: "tool", name: "kanban_view", label: "Kanban view", running: true }])).toBe("/ Kanban view");
  });
  it("marks a failed tool with fail", () => {
    expect(streamToText([{ kind: "tool", name: "x", running: false, ok: false }])).toBe("/ x fail");
  });
  it("keeps consecutive tool calls tight (single newline)", () => {
    const items: StreamItem[] = [
      { kind: "tool", name: "a", running: false, ok: true },
      { kind: "tool", name: "b", running: false, ok: true },
    ];
    expect(streamToText(items)).toBe("/ a ok\n/ b ok");
  });
  it("fences a banner with horizontal rules", () => {
    const items: StreamItem[] = [{ kind: "banner", text: "model: claude-opus\ncwd: ~/dev" }];
    expect(streamToText(items)).toBe(`${RULE}\n model: claude-opus\n cwd: ~/dev\n${RULE}`);
  });
  it("separates a banner from following text with a blank line", () => {
    const items: StreamItem[] = [
      { kind: "banner", text: "model: x" },
      { kind: "user", text: "hi" },
    ];
    expect(streamToText(items)).toBe(`${RULE}\n model: x\n${RULE}\n> hi`);
  });
  it("returns empty string for an empty stream", () => {
    expect(streamToText([])).toBe("");
  });
});

describe("measured wrapping", () => {
  it("wraps long text to the measured body width", () => {
    const lines = wrapTextLines("x".repeat(140));
    expect(lines.length).toBeGreaterThan(1);
    for (const line of lines) expect(getTextWidth(line)).toBeLessThanOrEqual(THREAD_BODY_INNER_WIDTH);
  });

  it("preserves explicit line breaks", () => {
    expect(wrapTextLines("a\nb\nc")).toEqual(["a", "b", "c"]);
  });
});

describe("threadPages", () => {
  it("renders then returns measured viewports", () => {
    const items: StreamItem[] = [{ kind: "user", text: "hi" }];
    expect(threadPages(items)).toEqual(["> hi"]);
  });

  it("creates overlapping viewport windows by measured line capacity", () => {
    const lines = Array.from({ length: THREAD_VIEWPORT_LINES + 1 }, (_, i) => `line ${i + 1}`);
    const items: StreamItem[] = [{ kind: "assistant", text: lines.join("\n") }];
    const viewports = threadViewports(items);

    expect(viewports).toHaveLength(2);
    expect(viewports[0].content).toBe(lines.slice(0, THREAD_VIEWPORT_LINES).join("\n"));
    expect(viewports[1].content).toBe(lines.slice(1).join("\n"));
  });

  it("uses null as follow-latest mode", () => {
    const lines = Array.from({ length: THREAD_VIEWPORT_LINES + 1 }, (_, i) => `line ${i + 1}`);
    const items: StreamItem[] = [{ kind: "assistant", text: lines.join("\n") }];

    expect(currentThreadViewport(items, null).index).toBe(1);
    expect(previousThreadViewportIndex(items, null)).toBe(0);
    expect(nextThreadViewportCursor(items, 0)).toBeNull();
  });
});

// body container: width 576, paddingLength 4 → 568px usable (see ui/render.ts)
const BODY_INNER_PX = 576 - 2 * 4;

describe("banner divider", () => {
  it("every banner line fits one display line", () => {
    const out = streamToText([{ kind: "banner", text: "model: claude\ncwd: /home/u" }]);
    for (const line of out.split("\n")) {
      expect(getTextWidth(line)).toBeLessThanOrEqual(BODY_INNER_PX);
    }
  });
});

describe("the SDK's silent byte limit", () => {
  // rebuildPageContainer and textContainerUpgrade reject content over ~999
  // bytes by resolving false — no throw, no log, the screen just does not
  // change. Wrapping is by pixel width, which does not bound UTF-8 length.
  it("keeps every viewport under the budget for wide non-ASCII text", () => {
    const stream = [{ kind: "assistant" as const, text: "日本語のとても長い返事。".repeat(60) }];
    for (const page of threadPages(stream)) {
      expect(byteLength(page)).toBeLessThanOrEqual(VIEWPORT_BYTE_BUDGET);
    }
  });

  it("caps a single oversized line, not just the joined total", () => {
    expect(byteLength(clampToBudget(["x".repeat(5_000)]))).toBeLessThanOrEqual(VIEWPORT_BYTE_BUDGET);
  });

  it("drops from the front so the newest text survives", () => {
    const lines = Array.from({ length: 40 }, (_, i) => `line ${i} ${"y".repeat(60)}`);
    const out = clampToBudget(lines);
    expect(out).toContain("line 39");
    expect(out).not.toContain("line 0 ");
  });
});
